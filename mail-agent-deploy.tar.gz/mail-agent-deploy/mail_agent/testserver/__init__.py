"""AI Mail Redirection Agent - Test server package."""

from .server import TestMailServer

__all__ = ["TestMailServer"]
